# 📦 Como Instalar — Daudas Xianyu Helper

> Extensão para Chrome que analisa vendedores e produtos no **Goofish (Xianyu)** e **CSSBuy**.  
> Instalação em menos de 2 minutos, sem cadastro.

---

## ✅ Requisitos

- Google Chrome (ou navegador baseado em Chromium: Brave, Edge, Opera)
- Os arquivos da extensão (pasta com `manifest.json` + `content.js` + imagens)

---

## 📥 Passo 1 — Baixe os arquivos

Baixe o `.zip` da extensão e extraia em uma pasta fácil de encontrar, por exemplo:

```
C:\Users\SeuNome\Downloads\daudas-xianyu-helper\
```

A pasta deve conter ao menos:
```
daudas-xianyu-helper/
├── manifest.json
├── content.js
├── logo.png
├── logodaudas.png
└── logocss.png
```

---

## 🔧 Passo 2 — Abra as extensões do Chrome

No Chrome, acesse:

```
chrome://extensions
```

Ou pelo menu:  
**⋮ Menu → Mais ferramentas → Extensões**

---

## 🛠️ Passo 3 — Ative o Modo do Desenvolvedor

No canto **superior direito** da página de extensões, ative o toggle:

```
🔲 Modo do desenvolvedor  →  ✅ Modo do desenvolvedor
```

---

## 📂 Passo 4 — Carregue a extensão

Clique no botão que vai aparecer:

```
[ Carregar sem compactação ]
```

Selecione a **pasta** onde estão os arquivos (não o `.zip`, a pasta extraída).  
O Chrome vai carregar a extensão automaticamente.

---

## 📌 Passo 5 — Fixe na barra do Chrome

1. Clique no ícone de **quebra-cabeça 🧩** no canto superior direito do Chrome
2. Encontre **Daudas Xianyu Helper**
3. Clique no **alfinete 📌** para fixar na barra

---

## 🚀 Como usar

1. Acesse qualquer anúncio no [Goofish](https://www.goofish.com) ou [CSSBuy](https://www.cssbuy.com)
2. O painel aparece automaticamente no **canto superior esquerdo** da tela
3. Clique no ícone para minimizar ou expandir

---

## 🔄 Como atualizar após editar o código

Sempre que editar o `content.js`:

1. Vá em `chrome://extensions`
2. Encontre a extensão
3. Clique em **🔄 Atualizar**
4. Recarregue a página do Goofish/CSSBuy

---

## ❓ Problemas comuns

| Problema | Solução |
|---|---|
| Painel não aparece | Recarregue a página e aguarde 3s |
| "Erro ao carregar extensão" | Verifique se o `manifest.json` está na raiz da pasta |
| Cotação mostra N/A | Clique em **Atualizar** no painel ou mude para modo Manual |
| Vendedor mostra Neutro | Os dados do vendedor ainda estão carregando — aguarde e recarregue |

---

## 📞 Suporte

Entre em contato pelo grupo ou abra uma issue no repositório.  
Feito com 💜 por **Daudas** — Fork do original por **Slet**
