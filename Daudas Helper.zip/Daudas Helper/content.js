/* =============================================================
   DAUDAS XIANYU HELPER — BETA
   =============================================================
   Este projeto é um FORK do Xianyu Helper original criado por:

       SLET (Garfo de Slet)
       Licença original: CC BY-NC-SA 4.0
       https://creativecommons.org/licenses/by-nc-sa/4.0/

   Modificações, novas funcionalidades e manutenção por:
       DAUDAS

   TERMOS DA LICENÇA CC BY-NC-SA 4.0:
   ✅ Permitido: compartilhar e adaptar o código
   ✅ Obrigatório: manter crédito ao autor original (Slet)
   ✅ Obrigatório: distribuir com a mesma licença
   ❌ Proibido: uso comercial sem autorização expressa do autor

   Ao usar, modificar ou redistribuir este código,
   você DEVE manter este cabeçalho intacto.
   ============================================================= */

const DEBUG = false;
if (DEBUG) {
    console.log("%c Daudas Xianyu Helper BETA-beta - Ativo ", "color: #ffda00; background: #2c3e50; font-weight: bold; font-size: 14px;");
}

// --- 1. CONFIGURAÇÕES ---
const DEFAULT_RATE = 1.22;
const RATE_STORAGE_KEY = 'daudas_manual_rate';
const RATE_MODE_STORAGE_KEY = 'daudas_rate_mode';
const ANALYSIS_MODE_STORAGE_KEY = 'daudas_analysis_mode';
const AUTO_RATE_STORAGE_KEY = 'daudas_auto_rate';
const AUTO_RATE_UPDATED_STORAGE_KEY = 'daudas_auto_rate_updated';
const AUTO_RATE_CACHE_MS = 15 * 60 * 1000;

const FOTO_GOOFISH_LOCAL = chrome.runtime.getURL('logo.png');
const FOTO_GRUPO_LOCAL = chrome.runtime.getURL('logodaudas.png');
const FOTO_CSSBUY_LOCAL = chrome.runtime.getURL('logocss.png');

// Extrai apenas os dígitos do ID do produto, ignorando outros params da URL
const getCleanItemID = () => {
    const raw = new URLSearchParams(window.location.search).get('id');
    if (!raw) return null;
    const digits = raw.match(/\d+/);
    return digits ? digits[0] : null;
}; 

const readStorage = (key) => {
    try {
        return localStorage.getItem(key);
    } catch (_) {
        return null;
    }
};

const writeStorage = (key, value) => {
    try {
        localStorage.setItem(key, value);
    } catch (_) {
        // Ignora falhas de storage em modo restrito.
    }
};

const toNumberOrDefault = (value, fallback) => {
    const parsed = parseFloat(value);
    return Number.isFinite(parsed) ? parsed : fallback;
};

let taxaYuanReal = toNumberOrDefault(readStorage(RATE_STORAGE_KEY), DEFAULT_RATE);
let rateMode = readStorage(RATE_MODE_STORAGE_KEY) || 'manual';
let analysisMode = readStorage(ANALYSIS_MODE_STORAGE_KEY) || 'auto';
let lastAutoRate = toNumberOrDefault(readStorage(AUTO_RATE_STORAGE_KEY), 0);
let lastAutoRateUpdatedAt = parseInt(readStorage(AUTO_RATE_UPDATED_STORAGE_KEY) || '0', 10) || 0;
let rateFetchInFlight = null;
let lastProcessedUrl = '';

const formatRateUpdateLabel = () => {
    if (!lastAutoRateUpdatedAt) return 'nunca';
    return new Date(lastAutoRateUpdatedAt).toLocaleString('pt-BR');
};

const fetchAutoRate = async (force = false) => {
    const now = Date.now();
    const cacheIsFresh = now - lastAutoRateUpdatedAt < AUTO_RATE_CACHE_MS;
    if (!force && cacheIsFresh && lastAutoRate > 0) {
        taxaYuanReal = lastAutoRate;
        return false;
    }

    if (rateFetchInFlight) return false;

    rateFetchInFlight = fetch('https://economia.awesomeapi.com.br/json/last/CNY-BRL')
        .then((response) => {
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            return response.json();
        })
        .then((data) => {
            const bid = parseFloat(data?.CNYBRL?.bid);
            if (!Number.isFinite(bid) || bid <= 0) throw new Error('Cotação inválida');

            // A API retorna BRL por CNY; aqui usamos CNY por BRL para manter a fórmula atual.
            const autoRate = Number((1 / bid).toFixed(4));
            if (!Number.isFinite(autoRate) || autoRate <= 0) throw new Error('Conversão inválida');

            lastAutoRate = autoRate;
            lastAutoRateUpdatedAt = Date.now();
            taxaYuanReal = autoRate;
            writeStorage(AUTO_RATE_STORAGE_KEY, String(autoRate));
            writeStorage(AUTO_RATE_UPDATED_STORAGE_KEY, String(lastAutoRateUpdatedAt));
            return true;
        })
        .catch(() => false)
        .finally(() => {
            rateFetchInFlight = null;
        });

    return rateFetchInFlight;
};

const parseYuanValue = (text) => {
    const cleaned = text.replace(/\s/g, '').replace(/,/g, '').replace(/[^\d.]/g, '');
    const parsed = parseFloat(cleaned);
    return Number.isFinite(parsed) ? parsed : null;
};

const NOTEBOOK_ISSUE_RULES = [
    { label: 'Tela com defeito', pattern: /dead\s?pixel|stuck\s?pixel|burn\s?in|ghosting|坏点|亮点|花屏|白斑|漏光|屏幕问题/i, penalty: 18 },
    { label: 'Bateria trocada/desgaste', pattern: /troca de bateria|battery replaced|电池更换|电池维修|battery service/i, penalty: 10 },
    { label: 'Sem carregador', pattern: /sem carregador|without charger|charger not included|不带充电器|无充电器/i, penalty: 8 },
    { label: 'Teclado com falha', pattern: /teclado falhando|keyboard issue|key not working|按键失灵|键盘问题/i, penalty: 14 },
    { label: 'Face ID/Touch ID falho', pattern: /touch id fail|face id fail|指纹坏|面容坏|指纹失灵/i, penalty: 12 },
    { label: 'Dano por líquido', pattern: /liquid damage|water damage|进水|受潮/i, penalty: 28 },
    { label: 'Placa reparada', pattern: /logic board repair|board repair|主板维修|修过主板/i, penalty: 24 }
];

const IPHONE_ISSUE_RULES = [
    { label: 'Tela trocada', pattern: /换屏|屏幕更换|screen replaced|display replaced/i, penalty: 16 },
    { label: 'Bateria trocada', pattern: /换电池|电池更换|battery replaced|battery service/i, penalty: 10 },
    { label: 'Face ID com falha', pattern: /face id fail|face id issue|面容坏|面容失灵/i, penalty: 22 },
    { label: 'Touch ID com falha', pattern: /touch id fail|touch id issue|指纹坏|指纹失灵/i, penalty: 18 },
    { label: 'Sem True Tone', pattern: /true tone off|无原彩|没有原彩/i, penalty: 10 },
    { label: 'Refurb/recondicionado', pattern: /refurb|recondicionado|翻新/i, penalty: 20 },
    { label: 'Dano por líquido', pattern: /进水|liquid damage|water damage/i, penalty: 26 }
];

const SELLER_LEVEL_PATTERNS = [
    { label: 'Crédito excelente', pattern: /信用极好|信誉极好|excellent credit|极好/, bonus: 10 },
    { label: 'Crédito bom', pattern: /信用良好|信誉良好|good credit|良好/, bonus: 6 },
    { label: 'Crédito médio', pattern: /信用一般|信誉一般|average credit|一般/, bonus: 0 },
    { label: 'Crédito baixo', pattern: /信用较差|信誉较差|poor credit|较差/, bonus: -18 }
];

const CHINESE_NUM_MAP = {
    '一': 1,
    '二': 2,
    '三': 3,
    '四': 4,
    '五': 5,
    '六': 6,
    '七': 7,
    '八': 8,
    '九': 9,
    '十': 10
};

const parseChineseYearToken = (text) => {
    if (!text) return null;
    if (/^十$/.test(text)) return 10;
    if (/^十[一二三四五六七八九]$/.test(text)) return 10 + CHINESE_NUM_MAP[text[1]];
    if (/^[一二三四五六七八九]十$/.test(text)) return CHINESE_NUM_MAP[text[0]] * 10;
    if (/^[一二三四五六七八九]$/.test(text)) return CHINESE_NUM_MAP[text];
    return null;
};

const normalizeGbValue = (value, unit) => {
    const numeric = parseInt(value, 10);
    if (!Number.isFinite(numeric)) return null;
    return unit.toLowerCase() === 'tb' ? numeric * 1024 : numeric;
};

const extractCapacityCandidates = (text) => {
    const matches = [...text.matchAll(/(\d{1,4})\s?(gb|tb)/gi)];
    return matches
        .map((m) => {
            const gb = normalizeGbValue(m[1], m[2]);
            if (!gb) return null;
            return { raw: `${m[1]}${m[2].toUpperCase()}`, gb };
        })
        .filter(Boolean);
};

const formatStorageRaw = (gbValue) => {
    if (!Number.isFinite(gbValue)) return 'N/A';
    if (gbValue >= 1024 && gbValue % 1024 === 0) return `${gbValue / 1024}TB`;
    return `${gbValue}GB`;
};

const detectProductType = (text) => {
    const iphoneSignals = [
        /iphone|苹果手机|ios|face\s?id|a1\d\s?bionic|电池健康|原彩|灵动岛|applecare|美版|国行/i,
        /\b(11|12|13|14|15|16)\s?(pro|max|plus|mini)\b/i,
        /icloud|激活锁|有锁|无锁/i
    ];
    const notebookSignals = [
        /notebook|laptop|macbook|thinkpad|拯救者|游戏本|笔记本|联想|戴尔|惠普|华硕|宏碁|机械革命|轻薄本|办公本/i,
        /rtx|gtx|mx\d+|i[3579]-?\d{4,5}|ryzen\s?[3579]|m\.2|nvme|pcie|内存\s*\d+g/i,
        /13寸|14寸|15寸|16寸|17寸|inch/i
    ];
    const peripheralSignals = [
        /\bop[123]\b|\bop1w\b|\bop1we\b|\bop18k\b|gpro|g\s?pro|superlight|deathadder|viper|basilisk|rival|sensei|ec[12s]?|xlite|model\s?[odpr]|haste\s?[12]/i,
        /logitech|razer|corsair|steelseries|hyperx|roccat|glorious|zowie|benq|vaxee|endgame\s?gear|pulsar|lamzu|ninjutso|finalmouse|attack\s?shark/i,
        /\batk\b|mchose|wlmouse|wl\s?mouse|darmoshark|skyloong|akko|fl.?esports|niz|iqunix|ajazz|aula|rapoo|delux|fantech/i,
        /\b(?:teclado|keyboard|mouse\b|fone\b|headset|headphone|mousepad|gamepad|webcam|microfone)\b/i,
        /键盘|鼠标|耳机|耳麦|鼠标垫|手柄|游戏鼠标|无线鼠标|有线鼠标|电竞外设|外设|游戏外设/i,
        /有线.*鼠|无线.*鼠|\b8k\b|wireless\s?mouse|wired\s?mouse|gaming\s?mouse/i
    ];

    const iphoneScore     = iphoneSignals.reduce((acc, p)     => acc + (p.test(text) ? 1 : 0), 0);
    const notebookScore   = notebookSignals.reduce((acc, p)   => acc + (p.test(text) ? 1 : 0), 0);
    const peripheralScore = peripheralSignals.reduce((acc, p) => acc + (p.test(text) ? 1 : 0), 0);

    if (iphoneScore >= 1 && iphoneScore > notebookScore && iphoneScore > peripheralScore) return 'iphone';
    if (notebookScore >= 1 && notebookScore > iphoneScore && notebookScore > peripheralScore) return 'notebook';
    if (peripheralScore >= 1) return 'peripheral';
    if (iphoneScore >= 1) return 'iphone';
    if (notebookScore >= 1) return 'notebook';
    return 'generic';
};

const extractLaptopBrand = (text) => {
    const brands = ['apple', 'dell', 'lenovo', 'thinkpad', 'hp', 'huawei', 'asus', 'acer', 'xiaomi', 'msi', 'honor', 'razer'];
    const cnToBrand = {
        '联想': 'Lenovo',
        '戴尔': 'Dell',
        '惠普': 'HP',
        '华硕': 'ASUS',
        '宏碁': 'Acer',
        '华为': 'Huawei',
        '小米': 'Xiaomi',
        '荣耀': 'Honor',
        '苹果': 'Apple',
        '机械革命': 'MECHREVO'
    };

    for (const [cn, normalized] of Object.entries(cnToBrand)) {
        if (text.includes(cn)) return normalized;
    }

    const found = brands.find((brand) => text.includes(brand));
    return found ? found.toUpperCase() : 'N/A';
};

const extractNotebookModel = (text) => {
    const patterns = [
        /macbook\s?(?:air|pro)?\s?(?:\d{2,4}|m[1234])?\s?(?:pro|max|ultra)?/i,
        /thinkpad\s?[a-z]\d{1,3}[a-z]{0,2}/i,
        /legion\s?[a-z]?\d{3,5}[a-z]{0,2}/i,
        /r\d{4,5}[a-z]{0,2}/i,
        /y\d{4,5}[a-z]{0,2}/i,
        /xps\s?\d{2,4}/i,
        /matebook\s?[a-z0-9\-]+/i,
        /rog\s?[a-z0-9\-]+/i,
        /surface\s?(?:laptop|book|pro)?\s?\d{0,2}/i,
        /暗影精灵\s?\d{1,2}/i,
        /拯救者\s?[a-z]?\d{3,5}[a-z]{0,2}/i,
        /小新\s?[a-z0-9\-]+/i,
        /灵耀\s?[a-z0-9\-]+/i,
        /无畏\s?[a-z0-9\-]+/i
    ];

    for (const pattern of patterns) {
        const match = text.match(pattern);
        if (match) return match[0].replace(/\s+/g, ' ').trim().toUpperCase();
    }

    return 'N/A';
};

const extractNotebookRam = (text) => {
    const explicit = text.match(/(?:ram|运行内存|内存)\D{0,8}(\d{1,3})\s?g(?:b)?/i);
    if (explicit) return `${parseInt(explicit[1], 10)}GB`;

    const candidates = extractCapacityCandidates(text).map((c) => c.gb).filter((gb) => gb <= 128);
    if (!candidates.length) return 'N/A';
    const likelyRam = Math.min(...candidates.filter((gb) => gb <= 64));
    return Number.isFinite(likelyRam) ? `${likelyRam}GB` : 'N/A';
};

const extractNotebookStorage = (text) => {
    const explicit = text.match(/(?:ssd|硬盘|固态|容量|storage)\D{0,10}(\d{2,4})\s?(gb|tb)/i);
    if (explicit) return formatStorageRaw(normalizeGbValue(explicit[1], explicit[2]));

    const candidates = extractCapacityCandidates(text).map((c) => c.gb).filter((gb) => gb >= 128);
    if (!candidates.length) return 'N/A';
    return formatStorageRaw(Math.max(...candidates));
};

const extractNotebookSsdType = (text) => {
    if (/nvme|pcie|m\.2\s?nvme|2280/i.test(text)) return 'NVMe (M.2)';
    if (/m\.2/i.test(text)) return 'M.2';
    if (/sata|2\.5\s?(inch|in)?/i.test(text)) return 'SATA';
    if (/emmc/i.test(text)) return 'eMMC';
    return 'Não especificado';
};

const collectIphoneAlerts = (text) => IPHONE_ISSUE_RULES.filter((rule) => rule.pattern.test(text));

const extractIphoneModel = (text) => {
    const model = text.match(/iphone\s?(?:se|x(?:r|s|s\s?max)?|11|12|13|14|15|16)(?:\s?(?:pro|max|plus|mini))?/i);
    return model ? model[0].replace(/\s+/g, ' ').toUpperCase() : 'iPhone (não identificado)';
};

const extractIphoneRam = (text) => {
    const explicit = text.match(/(?:ram|运行内存)\D{0,8}(\d{1,2})\s?g(?:b)?/i);
    if (explicit) return `${parseInt(explicit[1], 10)}GB`;

    const candidates = extractCapacityCandidates(text).map((c) => c.gb).filter((gb) => gb > 0 && gb <= 16);
    if (!candidates.length) return 'N/A';
    return `${Math.max(...candidates)}GB`;
};

const extractIphoneStorage = (text) => {
    const explicit = text.match(/(?:容量|rom|storage|存储|机身内存)\D{0,8}(\d{2,4})\s?(gb|tb)/i);
    if (explicit) return formatStorageRaw(normalizeGbValue(explicit[1], explicit[2]));

    const candidates = extractCapacityCandidates(text).map((c) => c.gb).filter((gb) => gb >= 64);
    if (!candidates.length) return 'N/A';
    return formatStorageRaw(Math.max(...candidates));
};

const extractIphoneBatteryHealth = (text) => {
    const health = text.match(/(?:电池健康|battery\s?health|sa[uú]de\s?da\s?bateria)\D{0,10}(\d{2,3})\s?%?/i);
    if (!health) return 'N/A';
    const value = parseInt(health[1], 10);
    return Number.isFinite(value) && value <= 100 ? `${value}%` : 'N/A';
};

const extractIphoneFaceIdStatus = (text) => {
    if (/face\s?id\s?(?:fail|error|broken|issue|not\s?work)|面容\s?id\s?(?:坏|失灵|不可用)|无面容|面容不可用/i.test(text)) {
        return 'Com problema';
    }
    if (/face\s?id\s?(?:ok|works|working|funciona|perfeito|normal)|面容\s?id\s?(?:灵敏|正常|可用|好用)|面容解锁正常/i.test(text)) {
        return 'Funcionando';
    }
    return 'Não informado';
};

const extractIphoneLockStatus = (text) => {
    if (/icloud\s?lock|id\s?lock|激活锁|有锁|监管机|mdm/i.test(text)) return 'Bloqueado (risco alto)';
    if (/id已退|已退id|退出id|无锁|解锁|可登自己id/i.test(text)) return 'Sem bloqueio informado';
    return 'Não informado';
};

const extractIphoneReplacedParts = (text) => {
    const parts = [];
    if (/换屏|屏幕更换|screen replaced|display replaced/i.test(text)) parts.push('Tela');
    if (/换电池|电池更换|battery replaced/i.test(text)) parts.push('Bateria');
    if (/后盖更换|back glass replaced|carcaça trocada/i.test(text)) parts.push('Carcaça/Traseira');
    if (/摄像头更换|camera replaced/i.test(text)) parts.push('Câmera');
    if (/听筒更换|speaker replaced|alto falante trocado/i.test(text)) parts.push('Áudio');
    return parts;
};

const computeIphoneScore = ({ alerts, batteryHealth, fullText }) => {
    let score = 100;
    alerts.forEach((alert) => {
        score -= alert.penalty;
    });

    if (batteryHealth !== null) {
        if (batteryHealth < 80) score -= 20;
        else if (batteryHealth < 85) score -= 10;
        else if (batteryHealth < 90) score -= 5;
    }

    if (/id lock|icloud lock|激活锁|有锁/i.test(fullText)) score -= 50;
    if (/全新|未使用|like new|99新/i.test(fullText)) score += 4;

    score = Math.max(0, Math.min(100, score));
    const level = score >= 80 ? 'Baixo risco' : score >= 60 ? 'Atenção' : 'Alto risco';
    return { score, level };
};

const detectSellerMetrics = (container) => {
    const sources = [];
    if (container) sources.push(container.textContent || '');

    const sellerBlocks = document.querySelectorAll(
        '.item-user-info-intro--ZN1A0_8Y, [class*="item-user-info-intro--"], [class*="item-user-info-label--"], [class*="user-info"], [class*="credit"], [class*="seller"]'
    );
    sellerBlocks.forEach((node) => {
        if (node) sources.push(node.textContent || '');
    });

    if (document.body) {
        sources.push((document.body.textContent || '').slice(0, 20000));
    }

    const scopedText = sources.join(' ');

    let sold = null;
    let rating = null;
    let years = null;

    const labelNodes = document.querySelectorAll('[class*="item-user-info-label--"], [class*="user-info-label"], [class*="credit"]');
    labelNodes.forEach((node) => {
        const t = (node.textContent || '').trim();

        const soldMatch = t.match(/(\d{1,7})\s*(?:件宝贝|件|单|笔)/) || t.match(/卖出\s*(\d{1,7})/);
        const ratingMatch = t.match(/(\d{2,3})\s*%?/);

        if (/卖出|已售出|已卖出|件宝贝|vendas?/i.test(t) && soldMatch) {
            sold = parseInt(soldMatch[1], 10);
        }
        if (/好评率|rating|nota|positive/i.test(t) && ratingMatch) {
            rating = parseInt(ratingMatch[1], 10);
        }
    });

    // Fallback — scopedText completo
    if (!Number.isFinite(sold)) {
        // Tenta capturar o número entre 卖出 e 件, mesmo com espaços ou quebras
        const patterns = [
            /卖出\s*(\d{1,7})\s*件/,
            /(\d{1,7})\s*件宝贝/,
            /已售出?\s*(\d{1,7})/,
            /卖出(\d{1,7})/,       // sem 件 depois — pega só o número após 卖出
        ];
        for (const p of patterns) {
            const m = scopedText.match(p);
            if (m && parseInt(m[1], 10) > 0) {
                sold = parseInt(m[1], 10);
                break;
            }
        }
    }

    if (!Number.isFinite(rating)) {
        const m = scopedText.match(/好评率\s*(\d{2,3})\s*%?/);
        if (m) rating = parseInt(m[1], 10);
    }

    if (!Number.isFinite(years)) {
        const m =
            scopedText.match(/来闲鱼\s*(\d{1,2})\s*年/) ||
            scopedText.match(/(\d{1,2})\s*(?:年老店|anos?|years?)/i);
        if (m) {
            years = parseInt(m[1], 10);
        } else {
            const cn = scopedText.match(/([一二三四五六七八九十]{1,3})年(?:老店)?/);
            years = cn ? parseChineseYearToken(cn[1]) : null;
        }
    }

    const hasReliableMetrics = Number.isFinite(sold) || Number.isFinite(rating);
    if (!hasReliableMetrics) {
        return { sold, rating, years, score: null, risk: 'Dados insuficientes', reliable: false };
    }

    let score = 70;
    if (Number.isFinite(sold)) {
        if (sold >= 2000) score += 14;
        else if (sold >= 500) score += 10;
        else if (sold >= 100) score += 6;
        else if (sold >= 20) score += 2;
        else score -= 8;
    }

    if (Number.isFinite(rating)) {
        if (rating >= 99) score += 16;
        else if (rating >= 97) score += 10;
        else if (rating >= 95) score += 6;
        else if (rating < 90) score -= 12;
    }

    if (Number.isFinite(years)) {
        if (years >= 5) score += 6;
        else if (years >= 2) score += 3;
    }

    SELLER_LEVEL_PATTERNS.forEach((rule) => {
        if (rule.pattern.test(scopedText)) score += rule.bonus;
    });

    score = Math.max(0, Math.min(100, score));
    const risk = score >= 80 ? 'Baixo risco' : score >= 60 ? 'Risco moderado' : 'Alto risco';
    return { sold, rating, years, score, risk, reliable: true };
};

const extractCpu = (text) => {
    const intel = text.match(/i[3579][-\s]?\d{4,5}[a-z]{0,2}/i);
    if (intel) return intel[0].toUpperCase().replace(/\s+/g, '');

    const ryzen = text.match(/ryzen\s?[3579][\s-]?\d{3,4}[a-z]{0,2}/i);
    if (ryzen) return ryzen[0].toUpperCase().replace(/\s+/g, ' ');

    const mSeries = text.match(/apple\s?m[1234](\s?(pro|max|ultra))?/i) || text.match(/\bm[1234](\s?(pro|max|ultra))?\b/i);
    if (mSeries) return mSeries[0].toUpperCase().replace(/\s+/g, ' ');

    return 'N/A';
};

const extractGpu = (text) => {
    const nvidia = text.match(/rtx\s?\d{3,4}|gtx\s?\d{3,4}|mx\s?\d{2,3}/i);
    if (nvidia) return nvidia[0].toUpperCase().replace(/\s+/g, '');

    const amd = text.match(/rx\s?\d{4,5}[a-z]{0,2}|radeon\s\w+/i);
    if (amd) return amd[0].toUpperCase();

    const appleGpu = text.match(/(\d{1,2})-?core\s?gpu/i);
    if (appleGpu) return `${appleGpu[1]}-CORE GPU`;

    if (/integrated|核显|集成显卡|uhd|iris\s?xe/i.test(text)) return 'Integrada';
    return 'N/A';
};

const extractScreenSize = (text) => {
    const match = text.match(/(1[2-7](?:\.\d)?)\s?(?:inch|in|\")/i) || text.match(/(1[2-7](?:\.\d)?)(?=寸)/i);
    if (!match) return 'N/A';
    return `${match[1]}"`;
};

const collectNotebookAlerts = (text) => {
    return NOTEBOOK_ISSUE_RULES.filter((rule) => rule.pattern.test(text));
};

const computeNotebookScore = ({ hasMDM, batteryPercent, alerts, fullText }) => {
    let score = 100;
    if (hasMDM) score -= 40;

    if (batteryPercent !== null) {
        if (batteryPercent < 75) score -= 18;
        else if (batteryPercent < 85) score -= 10;
        else if (batteryPercent < 90) score -= 5;
    }

    alerts.forEach((alert) => {
        score -= alert.penalty;
    });

    if (/拆修|opened|repaired|维修|拆机/i.test(fullText)) score -= 8;
    if (/全新|未使用|like new|99新/i.test(fullText)) score += 5;

    score = Math.max(0, Math.min(100, score));
    const level = score >= 80 ? 'Baixo risco' : score >= 60 ? 'Atenção' : 'Alto risco';
    return { score, level };
};

// --- 2. BLOQUEIO SILENCIOSO E ESTILOS ---
const injectSilencerStyles = () => {
    if (document.getElementById('slet-silencer-styles')) return;
    const style = document.createElement('style');
    style.id = 'slet-silencer-styles';
    style.innerHTML = `
        .ant-modal-root, .ant-modal-mask, .ant-modal-wrap, 
        .loginCon--d9IpwYeU, .login-modal-wrapper, [role="dialog"],
        .ant-modal, .login-iframe-wrap--gc03OP5a, .closeIconBg--cubvOqVh { 
            display: none !important; visibility: hidden !important; pointer-events: none !important; opacity: 0 !important;
        }
        html, body { overflow: auto !important; height: auto !important; position: relative !important; }
        @keyframes blink { 0% { opacity: 1; } 50% { opacity: 0.3; } 100% { opacity: 1; } }
        #taxa-mode option, #analysis-mode option { color: #111 !important; background: #fff !important; }
        .slet-minimized { 
            width: 44px !important; height: 44px !important; padding: 0 !important; 
            background-color: transparent !important; border: none !important;
            box-shadow: none !important; display: flex !important;
            align-items: center !important; justify-content: center !important;
            overflow: visible !important; cursor: pointer; transition: 0.3s; 
        }
        .slet-minimized .slet-content, .slet-minimized #btn-minimize, .slet-minimized .slet-title-text { display: none !important; }
        .slet-minimized #slet-toggle-btn img { border: none !important; width: 44px !important; height: 44px !important; box-shadow: 0 4px 12px rgba(0,0,0,0.3); }
    `;
    document.head.appendChild(style);
};

// --- 3. CONVERSOR DE PREÇO ---
const convertPrice = (badge) => {
    const priceEl = document.querySelector('[class*="priceText--"]') || 
                    document.querySelector('[class*="price--"]') ||
                    document.querySelector('.price--OEWLbcxC');
    
    if (!priceEl) return;
    const oldSection = document.getElementById('price-conv-section');
    if (oldSection) oldSection.remove();

    const rawText = priceEl.innerText.replace(/¥/g, '').trim();
    let displayReal = "";

    if (rateMode === 'auto' && lastAutoRate > 0) {
        taxaYuanReal = lastAutoRate;
    }

    if (rawText.includes('-') || rawText.includes('~') || rawText.includes('–')) {
        const parts = rawText.split(/-|~|–/).map(parseYuanValue).filter((v) => v !== null);
        if (parts.length < 2 || taxaYuanReal <= 0) return;
        const realMin = (parts[0] / taxaYuanReal).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        const realMax = (parts[1] / taxaYuanReal).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        displayReal = `${realMin} - ${realMax}`;
    } else {
        const valorYuan = parseYuanValue(rawText);
        if (valorYuan === null || taxaYuanReal <= 0) return;
        displayReal = (valorYuan / taxaYuanReal).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    }

    const priceDiv = document.createElement('div');
    priceDiv.id = 'price-conv-section';
    priceDiv.className = 'slet-content'; 
    priceDiv.innerHTML = `
        <hr style="border: 0; border-top: 1px solid rgba(255,255,255,0.15); margin: 10px 0;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 3px;">
            <span style="font-size: 12px; font-weight: bold; color: #5efb6e; opacity: 0.9;">💰 Valor em R$:</span>
            <input type="number" id="taxa-manual" step="0.01" min="0.01" value="${taxaYuanReal}" 
                style="width: 42px; background: rgba(114,49,114,0.4); border: 1px solid rgba(255,255,255,0.2); color: #fff; font-size: 10px; border-radius: 3px; text-align: center;">
        </div>
        <div style="display: flex; gap: 6px; align-items: center; margin: 4px 0 8px;">
            <select id="taxa-mode" style="flex: 1; background: rgba(114,49,114,0.4); border: 1px solid rgba(255,255,255,0.2); color: #fff; font-size: 10px; border-radius: 3px; padding: 2px 4px;">
                <option value="manual" ${rateMode === 'manual' ? 'selected' : ''}>Manual</option>
                <option value="auto" ${rateMode === 'auto' ? 'selected' : ''}>Automática (API)</option>
            </select>
            <button id="taxa-refresh" style="background: rgba(255,255,255,0.12); border: 1px solid rgba(255,255,255,0.2); color: #fff; font-size: 10px; border-radius: 3px; padding: 2px 6px; cursor: pointer;">Atualizar</button>
        </div>
        <div style="font-size: 9px; opacity: 0.75; margin-bottom: 6px;">Fonte: ${rateMode === 'auto' ? `AwesomeAPI (${formatRateUpdateLabel()})` : 'Manual'}</div>
        <div style="font-size: ${displayReal.length > 18 ? '16px' : '22px'}; font-weight: 900; color: #fff; letter-spacing: -0.5px;">${displayReal}</div>
        
        <div style="margin-top: 12px; padding-top: 8px; border-top: 1px solid rgba(114,49,114,0.4); font-size: 7.5px; opacity: 0.5; text-align: center; line-height: 1.2; color: #eee;">
            ⚠️ Análise técnica apenas. Não é recomendação de compra.<br>
            🔧 <b>Daudas Helper</b> © 2026 — Fork do original por <b>Slet</b><br>
            📜 Licença: <a href="https://creativecommons.org/licenses/by-nc-sa/4.0/" target="_blank" style="color:#c084fc;">CC BY-NC-SA 4.0</a>
        </div>
    `;
    badge.appendChild(priceDiv);

    const taxaManualInput = document.getElementById('taxa-manual');
    const taxaModeSelect = document.getElementById('taxa-mode');
    const taxaRefreshButton = document.getElementById('taxa-refresh');

    taxaManualInput.disabled = rateMode === 'auto';
    taxaRefreshButton.disabled = rateMode !== 'auto';
    taxaRefreshButton.style.opacity = rateMode === 'auto' ? '1' : '0.5';
    taxaRefreshButton.style.cursor = rateMode === 'auto' ? 'pointer' : 'not-allowed';

    taxaManualInput.addEventListener('change', (e) => {
        const next = toNumberOrDefault(e.target.value, DEFAULT_RATE);
        taxaYuanReal = next > 0 ? next : DEFAULT_RATE;
        writeStorage(RATE_STORAGE_KEY, String(taxaYuanReal));
        convertPrice(badge);
    });

    taxaModeSelect.addEventListener('change', async (e) => {
        rateMode = e.target.value === 'auto' ? 'auto' : 'manual';
        writeStorage(RATE_MODE_STORAGE_KEY, rateMode);
        if (rateMode === 'auto') {
            await fetchAutoRate(true);
        } else {
            taxaYuanReal = toNumberOrDefault(readStorage(RATE_STORAGE_KEY), DEFAULT_RATE);
        }
        convertPrice(badge);
    });

    taxaRefreshButton.addEventListener('click', async () => {
        if (rateMode !== 'auto') return;
        await fetchAutoRate(true);
        convertPrice(badge);
    });

    if (rateMode === 'auto') {
        fetchAutoRate(false).then((updated) => {
            if (updated) convertPrice(badge);
        });
    }
};

// --- 4. SCANNER DE HARDWARE (BATERIA ANTI-CICLOS + EFICIÊNCIA) ---
const analyzeProduct = (badge) => {
    const desc = document.querySelector('.desc--GaIUKUQY') ||
        document.querySelector('[class*="desc--"]') ||
        document.querySelector('[class*="detail--"]') ||
        document.querySelector('[class*="content--"]') ||
        document.querySelector('[class*="description"]') ||
        document.querySelector('[class*="itemDesc"]');
    const labels = document.querySelector('.labels--ndhPFgp8') ||
        document.querySelector('[class*="labels--"]') ||
        document.querySelector('[class*="tag--"]') ||
        document.querySelector('[class*="label--"]');
    const titleEl = document.querySelector('h1') ||
        document.querySelector('[class*="title--"]') ||
        document.querySelector('[class*="itemTitle"]');
    // Captura extra: todos os textos visíveis na área principal do produto
    const extraBlocks = Array.from(document.querySelectorAll(
        '[class*="desc"], [class*="detail"], [class*="content"], [class*="info"], [class*="text"]'
    )).map(el => el.innerText || '').join(' ');
    if (document.getElementById('product-analysis-section')) return;

    const candidateText = [
        desc ? desc.innerText : '',
        labels ? labels.innerText : '',
        titleEl ? titleEl.innerText : '',
        extraBlocks || ''
    ].join(' ').trim();

    const fullText = (candidateText || (document.body ? (document.body.textContent || '').slice(0, 15000) : '')).toLowerCase();
    if (!fullText.trim()) return;
    const detectionText = `${fullText} ${(document.title || '').toLowerCase()} ${(window.location.href || '').toLowerCase()}`;
    const detectedType = detectProductType(detectionText);
    const activeMode = analysisMode === 'auto' ? detectedType : analysisMode;

    // Retry de identificação: se modo=auto e resultado=generic com texto curto,
    // a página pode não ter carregado ainda — agenda novas tentativas
    if (analysisMode === 'auto' && detectedType === 'generic') {
        if (!badge._detectRetryCount) badge._detectRetryCount = 0;
        if (badge._detectRetryCount < 5) {
            badge._detectRetryCount++;
            const sec = document.getElementById('product-analysis-section');
            if (sec) {
                const retryNote = sec.querySelector('#retry-note');
                if (!retryNote) {
                    const note = document.createElement('li');
                    note.id = 'retry-note';
                    note.style.cssText = 'color:#ffd700;font-size:10px;list-style:none;margin-top:4px';
                    note.textContent = `⏳ Identificando produto... (tentativa ${badge._detectRetryCount}/5)`;
                    const ul = sec.querySelector('ul');
                    if (ul) ul.appendChild(note);
                }
            }
            setTimeout(() => {
                const old = document.getElementById('product-analysis-section');
                if (old) old.remove();
                analyzeProduct(badge);
            }, 3500);
            return;
        }
        badge._detectRetryCount = 0;
    } else {
        badge._detectRetryCount = 0;
    }

    const hasMDM = /mdm|监管|绕过|bypass|enterprise|配置锁|管理锁/i.test(fullText);
    if (hasMDM) badge.dataset.mdm = 'true';

    let bateria = "N/A";
    const healthMatch = fullText.match(/(?:健康|容量|寿命|效率)[^\d]{0,10}?(\d{2,3})/);
    if (healthMatch && parseInt(healthMatch[1]) <= 100) {
        bateria = healthMatch[1] + "%";
    } else {
        const batPctMatch = fullText.match(/电池[^\d]{0,20}?(\d{2,3})\s?%/);
        if (batPctMatch && parseInt(batPctMatch[1]) <= 100) {
            bateria = batPctMatch[1] + "%";
        } else {
            const genericPct = fullText.match(/(\d{2,3})\s?%/);
            if (genericPct && parseInt(genericPct[1]) <= 100) {
                bateria = genericPct[1] + "%";
            } else {
                const batMatches = fullText.match(/电池[^\d]{0,30}?(\d{2,3})/g);
                if (batMatches) {
                    for (let m of batMatches) {
                        if (m.includes('循环')) continue;
                        let num = parseInt(m.match(/\d+/)[0]);
                        if (num > 0 && num <= 100) {
                            bateria = num + "%";
                            break;
                        }
                    }
                }
            }
        }
    }

    const batteryPercent = bateria.endsWith('%') ? parseInt(bateria, 10) : null;
    const numericBatteryPercent = Number.isFinite(batteryPercent) ? batteryPercent : null;
    const modeLabel = {
        auto: 'Automático',
        notebook: 'Notebook',
        iphone: 'iPhone',
        peripheral: 'Periférico',
        generic: 'Genérico'
    };

    let detailRows = '';
    if (activeMode === 'notebook') {
        const brand = extractLaptopBrand(fullText);
        const model = extractNotebookModel(fullText);
        const ram = extractNotebookRam(fullText);
        const ssd = extractNotebookStorage(fullText);
        const ssdType = extractNotebookSsdType(fullText);
        const cpu = extractCpu(fullText);
        const gpu = extractGpu(fullText);
        const tela = extractScreenSize(fullText);
        const notebookAlerts = collectNotebookAlerts(fullText);
        const notebookScore = computeNotebookScore({
            hasMDM,
            batteryPercent: numericBatteryPercent,
            alerts: notebookAlerts,
            fullText
        });

        detailRows = `
            <li>🏷️ Marca: ${brand}</li>
            <li>🧾 Modelo: ${model}</li>
            <li>💻 RAM: ${ram}</li>
            <li>💾 SSD: ${ssd} | Interface: ${ssdType}</li>
            <li>🧠 CPU: ${cpu} | 🎮 GPU: ${gpu}</li>
            <li>🖥️ Tela: ${tela}</li>
            <li>🔋 Bateria: ${bateria}</li>
            <li>📉 Score notebook: ${notebookScore.score}/100 (${notebookScore.level})</li>
            <li>⚠️ Alertas: ${notebookAlerts.length ? notebookAlerts.map((a) => a.label).join(', ') : 'Nenhum alerta textual encontrado'}</li>
        `;
    } else if (activeMode === 'iphone') {
        const model = extractIphoneModel(fullText);
        const ram = extractIphoneRam(fullText);
        const storage = extractIphoneStorage(fullText);
        const batteryHealth = extractIphoneBatteryHealth(fullText);
        const faceIdStatus = extractIphoneFaceIdStatus(fullText);
        const lockStatus = extractIphoneLockStatus(fullText);
        const replacedParts = extractIphoneReplacedParts(fullText);
        const iphoneAlerts = collectIphoneAlerts(fullText);
        const batteryHealthNumeric = batteryHealth.endsWith('%') ? parseInt(batteryHealth, 10) : null;
        const iphoneScore = computeIphoneScore({
            alerts: iphoneAlerts,
            batteryHealth: Number.isFinite(batteryHealthNumeric) ? batteryHealthNumeric : null,
            fullText
        });

        detailRows = `
            <li>📱 Modelo: ${model}</li>
            <li>🧠 Memória (RAM): ${ram}</li>
            <li>💽 Armazenamento: ${storage}</li>
            <li>🔋 Saúde da bateria: ${batteryHealth}</li>
            <li>🙂 Face ID: ${faceIdStatus}</li>
            <li>🔒 Bloqueio: ${lockStatus}</li>
            <li>🔧 Peças trocadas: ${replacedParts.length ? replacedParts.join(', ') : 'Sem trocas detectadas por texto'}</li>
            <li>📉 Score iPhone: ${iphoneScore.score}/100 (${iphoneScore.level})</li>
            <li>⚠️ Alertas: ${iphoneAlerts.length ? iphoneAlerts.map((a) => a.label).join(', ') : 'Nenhum alerta textual encontrado'}</li>
        `;
    } else if (activeMode === 'peripheral') {
        const condition = extractPeripheralCondition(fullText);
        const box = extractPeripheralBox(fullText);
        const accessories = extractPeripheralAccessories(fullText);
        const warranty = extractPeripheralWarranty(fullText);
        detailRows = `
            <li>📦 Estado: ${condition}</li>
            <li>🗃️ Caixa original: ${box}</li>
            <li>🔌 Acessórios: ${accessories}</li>
            <li>🛡️ ${warranty}</li>
        `;
    } else {
        const capacities = extractCapacityCandidates(fullText).map((c) => c.gb);
        const memoryCandidate = capacities.filter((gb) => gb > 0 && gb <= 32);
        const storageCandidate = capacities.filter((gb) => gb >= 64);
        const memory = memoryCandidate.length ? `${Math.max(...memoryCandidate)}GB` : 'N/A';
        const storage = storageCandidate.length ? formatStorageRaw(Math.max(...storageCandidate)) : 'N/A';

        detailRows = `
            <li>🧠 Memória: ${memory}</li>
            <li>💽 Armazenamento: ${storage}</li>
            <li>🔋 Bateria detectada: ${bateria}</li>
            <li>ℹ️ Modo automático ativo. Selecione manualmente: Notebook, iPhone ou Periférico para análise detalhada.</li>
        `;
    }

    const section = document.createElement('div');
    section.id = 'product-analysis-section';
    section.className = 'slet-content'; 
    section.innerHTML = `
        <hr style="border: 0; border-top: 1px solid rgba(255,255,255,0.15); margin: 10px 0;">
        <div style="font-weight: bold; font-size: 13px; color: #ffd700; margin-bottom: 4px; text-transform: uppercase;">📦 Especificações:</div>
        <div style="display: flex; gap: 6px; margin-bottom: 8px; align-items: center;">
            <span style="font-size: 10px; opacity: 0.9;">Modo:</span>
            <select id="analysis-mode" style="flex: 1; background: rgba(114,49,114,0.4); border: 1px solid rgba(255,255,255,0.2); color: #fff; font-size: 10px; border-radius: 3px; padding: 2px 4px;">
                <option value="auto" ${analysisMode === 'auto' ? 'selected' : ''}>Auto (${modeLabel[detectedType] || 'Genérico'})</option>
                <option value="notebook" ${analysisMode === 'notebook' ? 'selected' : ''}>Notebook</option>
                <option value="iphone" ${analysisMode === 'iphone' ? 'selected' : ''}>iPhone</option>
                <option value="peripheral" ${analysisMode === 'peripheral' ? 'selected' : ''}>Periférico</option>
                <option value="generic" ${analysisMode === 'generic' ? 'selected' : ''}>Genérico</option>
            </select>
        </div>
        <ul style="margin: 0; padding-left: 12px; font-size: 13px; list-style: disc; line-height: 1.5; color: rgba(255,255,255,0.9);">
            ${hasMDM ? `<li style="font-weight: bold; animation: blink 1s infinite; color: #ff4d4f;">🚨 MDM DETECTADO</li>` : ""}
            ${activeMode !== 'peripheral' ? `<li>🔧 Selado: ${fullText.includes('无拆') ? "✅ Sim" : "⚠️ Verificar"}</li>` : ''}
            ${detailRows}
        </ul>
    `;
    const priceSection = document.getElementById('price-conv-section');
    if (priceSection) {
        badge.insertBefore(section, priceSection);
    } else {
        badge.appendChild(section);
    }

    const modeSelect = document.getElementById('analysis-mode');
    if (modeSelect) {
        modeSelect.addEventListener('change', (e) => {
            analysisMode = e.target.value || 'auto';
            writeStorage(ANALYSIS_MODE_STORAGE_KEY, analysisMode);
            const old = document.getElementById('product-analysis-section');
            if (old) old.remove();
            const oldPeri = document.getElementById('peripheral-analysis-section');
            if (oldPeri) oldPeri.remove();
            analyzeProduct(badge);
            // Reposicionar recarga e cssbuy para ficarem ANTES da cotação
            const priceSecRef = badge.querySelector('#price-conv-section');
            const rechargeEl  = badge.querySelector('#daudas-recharge-btns');
            const cssbuyEl    = badge.querySelector('#cssbuy-main-btn');
            if (priceSecRef) {
                if (rechargeEl) badge.insertBefore(rechargeEl, priceSecRef);
                if (cssbuyEl)   badge.insertBefore(cssbuyEl,   priceSecRef);
            }
        });
    }
};


// --- 4b. MÓDULO PERIFÉRICOS ---
const PERIPHERAL_SIGNALS = [
  /teclado|keyboard|mouse|fone|headset|headphone|mousepad|joystick|controle|gamepad|webcam|microfone|microphone|monitor|hub\s?usb|fone\s?de\s?ouvido/i,
  /键盘|鼠标|耳机|耳麦|鼠标垫|手柄|控制器|游戏控制器|摄像头|麦克风|显示器|有线|无线.*鼠|鼠.*无线/i,
  // marcas e modelos populares de periféricos
  /logitech|razer|corsair|steelseries|hyperx|roccat|glorious|zowie|benq|asus\s?rog|finalMouse|vaxee/i,
  /\bop1\b|\bop2\b|\bop3\b|gpro|deathadder|viper|basilisk|rival|sensei|ec[12]|s[12]\s?mini|xlite|model[od]/i,
  /机械键盘|游戏鼠标|电竞|外设|gaming|periphera/i,
];

const detectPeripheral = (text) => PERIPHERAL_SIGNALS.some((p) => p.test(text));

const extractPeripheralCondition = (text) => {
    const _hasDefect = (t) => {
        const fraseVendedor = /有问题随时|有问题可以|有问题联系|有问题私聊|有问题滴滴/.test(t);

        const tSemAviso = t
            .replace(/检查包裹.*?污渍/g, '')
            .replace(/请注意.*?拒签/g, '')
            .replace(/签收.*?客服/g, '')
            .replace(/外观轻微划痕.*?下单/g, '');

        // Remove frases de negação antes de checar defeitos
        const tSemNegacao = tSemAviso
            .replace(/没有?[^\s，。！？,]{0,8}/g, '')   // 没XX / 没有XX
            .replace(/无[^\s，。！？,]{0,6}/g, '')        // 无XX
            .replace(/非[^\s，。！？,]{0,4}/g, '');       // 非XX

        const temDefeito = /defeito|quebrado|danificado|broken|damaged|故障|损坏|坏了|失灵|破损|漂移|双击|连击|失准/i.test(tSemNegacao);
        const temAnBing = /暗病/.test(t) && !/无暗病|没暗病|没有暗病/.test(t);
        const temYouWenti = /有问题/.test(t) && !fraseVendedor;

        return temDefeito || temAnBing || temYouWenti;
    };

    // 1. Defeito — prioridade máxima
    if (_hasDefect(text)) return '🔴 Com defeito';

    // 2. Quase sem uso — frases típicas
    if (/刚到手|刚买|刚入手|买来没怎么用|买了没用|买回来没用|到手就出|到手出|收到就出|收到出|没用几次|没用过几次|几乎没用|基本没用|很少用|极少用|闲置.*没用|没用.*闲置|成色几乎全新|几乎全新|外观很新/.test(text)) {
        return '🟡 Seminovo (quase sem uso)';
    }

    // 3. Pouco uso com tempo explícito
    if (/使用不超过[一\d]+[天个周月]|用了不到[一\d]+[天个周月]|只用了?[0-9一二三四五六七八九十]+[天个周月]|入手不到[一\d]+[天个周月]/.test(text)) {
        return '🟡 Seminovo (quase sem uso)';
    }
    if (/used\s?(less\s?than\s?)?\d+\s?days?|usado\s?\d+\s?dias?|menos de \d+ dias?/i.test(text)) {
        return '🟡 Seminovo (quase sem uso)';
    }

    // 4. Lacrado no passado mas já aberto
    if (/(?:estava|era|veio|chegou|comprei|recebi)\s+lacrad[oa]|lacrad[oa]\s+(?:mas|porém|só que|só q|abri|abriu)/i.test(text)) {
        return '🟡 Seminovo (lacrado na compra, já aberto)';
    }

    // 5a. 99新 / 个人一手自用 — quase novo, prioridade sobre lacrado
    if (/9[89]新|98新|个人一手自用|一手自用/.test(text)) {
        return '🟡 Seminovo (quase novo)';
    }

    // 5. Novo / Lacrado — sinal forte
    const sealedStrong = /全新未拆|未拆封|未开封|sealed|brand new|new in box|lacrado\b|lacrada\b/i.test(text);
    const sealedIsAccessoryOnly = /配件全新|附件全新/i.test(text) && !/全新未拆|未拆封|未开封/i.test(text);
    const temContextoUsado = /仅拆封|个人一手|一手自用|9[89]新|未拆未修|无拆无修|刚到手|没用|闲置/.test(text);
    if (sealedStrong && !sealedIsAccessoryOnly && !temContextoUsado) return '🟢 Lacrado / Novo';
    if (/全新/.test(text) && !temContextoUsado) return '🟢 Lacrado / Novo';

    // 6. Quase novo sem lacre (99新, 无拆无修, like new)
    if (/无拆无修|未拆未修|九成新|9[89]新|like new|seminovo|quase novo|pouco uso|个人一手|一手自用/i.test(text)) {
        return '🟡 Seminovo (quase novo)';
    }

    // 7. Usado por tempo
    if (/自用[了]?\d*[一二三四五六七八九十百零]+[年个月天]|自用一年多|自用了?\d+[年个月天]/.test(text)) {
        return '🟠 Usado';
    }
    if (/used|usado|二手|八成新|七成新|六成新|有使用痕迹|有划痕|有磨损|com uso|com desgaste/i.test(text)) {
        return '🟠 Usado';
    }

    return '⚪ Não informado';
};

const extractPeripheralBox = (text) => {
    // Sem caixa — só ativa se NÃO tiver menção de caixa presente
    if (/无盒(?!子都在)|没有盒子|盒子没了|无原盒|不含盒|不带盒|裸机|sem caixa|without box|no box/i.test(text)) {
        return '❌ Sem caixa original';
    }
    // Com caixa original
    if (/原包装盒|原盒|原装盒|带盒|有盒子|盒子都在|箱说全|包装配件齐全|盒说全|com caixa|with box|caixa original/i.test(text)) {
        return '✅ Com caixa original';
    }
    if (/包装|盒子|packaging/i.test(text)) {
        return '📦 Embalagem mencionada (verificar)';
    }
    return '⚪ Não informado';
};

const extractPeripheralAccessories = (text) => {
    if (/无配件|没有配件|不含配件|无接收器|没有接收器|接收器.*没有|sem acessórios|sem cabo|sem receptor|sem dongle|without accessories|no accessories/i.test(text)) {
        return '❌ Sem acessórios';
    }
    if (/配件全齐|配件齐全|全套配件|附件齐全|线材.*都在|接收器.*都在|都在.*接收器|含配件|含接收器|附配件|所有.*都在|物品都在|附件全|acessórios.*inclusos|receptor.*incluído/i.test(text)) {
        return '✅ Acessórios completos';
    }
    if (/配件|附件|接收器|线材|dongle|receptor|cabo|acessório/i.test(text)) {
        return '🟡 Acessórios mencionados (verificar)';
    }
    return '⚪ Não informado';
};

const extractPeripheralWarranty = (text) => {
    if (/质保还在|保修还在|还在保|在保中|质保期内|warranty.*valid|ainda.*garantia/i.test(text)) {
        return '✅ Garantia ainda válida';
    }
    const recentBuyMatch = text.match(/(\d{2})年(\d{1,2})月.*(?:购买|入手|买的|拍的)/);
    if (recentBuyMatch) {
        const year = 2000 + parseInt(recentBuyMatch[1]);
        const month = parseInt(recentBuyMatch[2]);
        const buyDate = new Date(year, month - 1);
        const now = new Date();
        const monthsDiff = (now.getFullYear() - buyDate.getFullYear()) * 12 + (now.getMonth() - buyDate.getMonth());
        if (monthsDiff <= 12) return `✅ Garantia provável (comprado ${recentBuyMatch[1]}/${String(recentBuyMatch[2]).padStart(2,'0')} — ${monthsDiff}m atrás)`;
    }
    if (/质保过期|过保|无保修|不在保|warranty.*expired|sem garantia|fora de garantia/i.test(text)) {
        return '❌ Garantia expirada';
    }
    if (/质保|保修|garantia|warranty|售后/i.test(text)) {
        const match = text.match(/(\d+)\s*(?:meses?|months?|anos?|years?|个月|年)/i);
        return match ? `🟡 Garantia mencionada: ${match[0]}` : '🟡 Garantia / suporte mencionado';
    }
    return '⚪ Garantia não mencionada';
};

const analyzePeripheral = (badge, fullText) => {
  if (document.getElementById('peripheral-analysis-section')) return;

  const condition = extractPeripheralCondition(fullText);
  const box = extractPeripheralBox(fullText);
  const accessories = extractPeripheralAccessories(fullText);
  const warranty = extractPeripheralWarranty(fullText);

  const section = document.createElement('div');
  section.id = 'peripheral-analysis-section';
  section.className = 'slet-content';
  section.innerHTML = `
    <hr style="border:0;border-top:1px solid rgba(255,255,255,0.15);margin:10px 0">
    <div style="font-weight:bold;font-size:11px;color:#ffd700;margin-bottom:6px;text-transform:uppercase">🎮 Periférico</div>
    <ul style="margin:0;padding-left:12px;font-size:11px;list-style:disc;line-height:1.6;color:rgba(255,255,255,0.9)">
      <li>Estado: ${condition}</li>
      <li>Caixa: ${box}</li>
      <li>Acessórios: ${accessories}</li>
      <li>${warranty}</li>
    </ul>
  `;

  const priceSection = document.getElementById('price-conv-section');
  if (priceSection) badge.insertBefore(section, priceSection);
  else badge.appendChild(section);
};

// --- 4c. BOTÃO CSSBUY GRANDE ---
const injectCSSBuyButton = (badge) => {
    if (document.getElementById('cssbuy-main-btn')) return;
    if (!window.location.href.includes('goofish.com')) return;
    const currentItemID = getCleanItemID();
    if (!currentItemID) return;

    const btnWrap = document.createElement('div');
    btnWrap.id = 'cssbuy-main-btn';
    btnWrap.className = 'slet-content';
    btnWrap.innerHTML = `
        <a href="https://www.cssbuy.com/item-xianyu-${currentItemID}.html?promotionCode=${CSSBUY_PROMOTION_CODE}"
           target="_blank" rel="noopener noreferrer"
           referrerpolicy="no-referrer"
           style="
               display:block;
               width:100%;
               box-sizing:border-box;
               text-align:center;
               background:#ffda00;
               color:#000;
               font-weight:900;
               font-size:15px;
               padding:12px 0;
               border-radius:8px;
               text-decoration:none;
               letter-spacing:1px;
               margin-top:8px;
               box-shadow:0 3px 10px rgba(255,218,0,0.4);
               transition:0.2s;
           "
           onmouseover="this.style.background='#ffe84d';this.style.transform='scale(1.02)'"
           onmouseout="this.style.background='#ffda00';this.style.transform='scale(1)'"
        ><img src="${FOTO_CSSBUY_LOCAL}" style="width:18px;height:18px;margin-right:8px;border-radius:3px;object-fit:cover;vertical-align:middle;">🛒 VER NO CSSBUY</a>
    `;
    const priceSec = badge.querySelector('#price-conv-section');
    if (priceSec) badge.insertBefore(btnWrap, priceSec);
    else badge.appendChild(btnWrap);
};


// --- 4d. BOTÕES DE RECARGA ---
const injectRechargeButtons = (container, big = false) => {
    if (document.getElementById('daudas-recharge-btns')) return;

    const titleSize  = big ? '15px' : '11px';
    const titleMb    = big ? '10px' : '8px';
    const btnSize    = big ? '15px' : '12px';
    const btnPadding = big ? '12px 0' : '8px 0';
    const btnRadius  = big ? '9px'   : '7px';
    const btnMb      = big ? '7px'   : '5px';

    const wrap = document.createElement('div');
    wrap.id = 'daudas-recharge-btns';
    wrap.className = 'slet-content';
    wrap.innerHTML = `
        <hr style="border:0;border-top:1px solid rgba(255,255,255,0.18);margin:8px 0 8px;">
        <div style="font-size:${titleSize};font-weight:900;color:#ffd700;margin-bottom:${titleMb};text-transform:uppercase;letter-spacing:0.5px;"> 💳 Recarregue seu saldo</div>
        <a href="https://bytemax.exchange?ref=DAUDAS" target="_blank" rel="noopener noreferrer"
           style="display:flex;align-items:center;justify-content:center;width:100%;box-sizing:border-box;
                  background:linear-gradient(135deg,#2d1b2d,#3d1f3d);color:#fff;font-weight:700;
                  font-size:${btnSize};padding:${btnPadding};border-radius:${btnRadius};text-decoration:none;
                  border:1px solid rgba(255,255,255,0.15);margin-bottom:${btnMb};
                  box-shadow:0 2px 8px rgba(0,0,0,0.3);transition:0.2s;"
           onmouseover="this.style.background='linear-gradient(135deg,#3d1f3d,#4d2a4d)'"
           onmouseout="this.style.background='linear-gradient(135deg,#2d1b2d,#3d1f3d)'"
        >⚡ ByteMax Exchange</a>
        <a href="https://noob.exchange?code=DAUDASIMPT" target="_blank" rel="noopener noreferrer"
           style="display:flex;align-items:center;justify-content:center;width:100%;box-sizing:border-box;
                  background:linear-gradient(135deg,#1f0f1f,#2d1b2d);color:#fff;font-weight:700;
                  font-size:${btnSize};padding:${btnPadding};border-radius:${btnRadius};text-decoration:none;
                  border:1px solid rgba(255,255,255,0.15);
                  box-shadow:0 2px 8px rgba(0,0,0,0.3);transition:0.2s;"
           onmouseover="this.style.background='linear-gradient(135deg,#2d1b2d,#3d1f3d)'"
           onmouseout="this.style.background='linear-gradient(135deg,#1f0f1f,#2d1b2d)'"
        >🟢 NoobExchange</a>
    `;
    const priceSec2 = container.querySelector('#price-conv-section');
    if (priceSec2) container.insertBefore(wrap, priceSec2);
    else container.appendChild(wrap);
};




// --- 5. BADGE PRINCIPAL COM TOGGLE E LÓGICA VIP ---
const analyzeSeller = () => {
    if (!window.location.href.includes('goofish.com')) return;
    const isItemPage = /[?&]id=\d+/.test(window.location.href) || /\/item/i.test(window.location.pathname);
    if (!isItemPage) return;

    // Detect SPA navigation — remove stale badge so everything re-creates
    const currentUrl = window.location.href;
    if (currentUrl !== lastProcessedUrl) {
        const oldBadge = document.getElementById('seller-status-badge');
        if (oldBadge) oldBadge.remove();
        const oldCSSBtn = document.getElementById('cssbuy-main-btn');
        if (oldCSSBtn) oldCSSBtn.remove();
        lastProcessedUrl = currentUrl;
    }

    const container = document.querySelector('.item-user-info-intro--ZN1A0_8Y') ||
        document.querySelector('[class*="item-user-info-intro--"]') ||
        document.querySelector('[class*="user-info"]');

    const metrics = detectSellerMetrics(container);
    const v = Number.isFinite(metrics.sold) ? metrics.sold : 0;
    const f = Number.isFinite(metrics.rating) ? metrics.rating : 0;

    let txt = '⚖️ Neutro';
    let col = '#2d1b2d';        // Neutro/Confiável: roxo escuro padrão
    let textCol = '#ffffff';    // cor do texto

    if (metrics.reliable) {
        if (metrics.score >= 80) {
            txt = '✅ Confiável';
            col = '#2d1b2d';    // igual ao padrão — confiável não muda a cor
            textCol = '#ffffff';
        } else if (metrics.score >= 60) {
            txt = '🟡 Mediano';
            col = '#6b5500';    // amarelo escuro — legível com texto claro
            textCol = '#ffe066';
        } else {
            txt = '⚠️ Perigoso';
            col = '#7f1d1d';    // vermelho escuro — legível com texto claro
            textCol = '#fca5a5';
        }
    }

    let b = document.getElementById('seller-status-badge');
    const isNewBadge = !b;
    if (!b) {
        b = document.createElement('div');
        b.id = 'seller-status-badge';
        b.innerHTML = `
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
                <div id="slet-toggle-btn" style="display: flex; align-items: center; cursor: pointer;">
                    <img src="${FOTO_GRUPO_LOCAL}" style="width: 36px; height: 36px; border-radius: 8px; object-fit: cover; border: 1px solid rgba(255,255,255,0.1);">
                    <div class="slet-title-text" style="font-weight: bold; font-size: 15px; color: #fff; line-height: 1.1; margin-left: 10px;">Daudas Xianyu</div>
                </div>
                <div class="slet-content" style="display: flex; gap: 6px; align-items: center;">
                    <div id="btn-minimize" style="cursor: pointer; padding: 5px; opacity: 0.6; font-weight: bold; color: #fff; font-size: 16px; line-height: 0.5;">_</div>
                </div>
            </div>
            <div class="slet-content" id="seller-info-wrap">
                <div id="seller-status-text" style="font-size: 13px; font-weight: bold; margin-bottom: 1px; color: rgba(255,255,255,0.9);"></div>
                <div id="seller-sales-text" style="font-size: 12px; opacity: 0.8; color: #eee;"></div>
                <div id="seller-profile-text" style="font-size: 12px; opacity: 0.85; color: #f8f8f8; margin-top: 4px;"></div>
                <div id="seller-years-text" style="font-size: 12px; opacity: 0.75; color: #ddd;"></div>
            </div>
        `;
    }

    b.style.backgroundColor = col;
    b.style.color = textCol;
    b.style.borderColor = col === '#2d1b2d' ? 'rgba(114,49,114,0.4)' : col;
    if (b.dataset.mdm === 'true') {
        b.style.backgroundColor = '#7f1d1d';
        b.style.color = '#fca5a5';
        b.style.borderColor = '#7f1d1d';
    }

    Object.assign(b.style, {
        position: 'fixed', top: '20px', left: '20px', zIndex: '2147483647',
        color: 'white', padding: '14px 16px', borderRadius: '14px',
        boxShadow: '0 6px 18px rgba(114,49,114,0.5)', fontFamily: 'Segoe UI, sans-serif', width: '320px',
        border: '1px solid rgba(114,49,114,0.4)', transition: '0.3s'
    });

    const statusEl = b.querySelector('#seller-status-text');
    const salesEl = b.querySelector('#seller-sales-text');
    const profileEl = b.querySelector('#seller-profile-text');
    const yearsEl = b.querySelector('#seller-years-text');
    if (statusEl) {
        statusEl.textContent = `Vendedor: ${txt}`;
        statusEl.style.color = textCol;
    }
    if (salesEl) salesEl.textContent = `Vendas: ${v || 'N/A'} | Nota: ${f ? `${f}%` : 'N/A'}`;
    if (profileEl) profileEl.textContent = `Perfil: ${metrics.reliable ? `${metrics.risk} (${metrics.score}/100)` : 'Dados insuficientes'}`;
    if (yearsEl) yearsEl.textContent = `Tempo de loja: ${Number.isFinite(metrics.years) ? metrics.years : 'N/A'} anos`;


    if (isNewBadge) {
        document.body.appendChild(b);
        const toggleBadge = () => b.classList.toggle('slet-minimized');
        const minBtn = b.querySelector('#btn-minimize');
        const toggleBtn = b.querySelector('#slet-toggle-btn');
        if (minBtn) {
            minBtn.onclick = (e) => {
                e.stopPropagation();
                toggleBadge();
            };
        }
        if (toggleBtn) {
            toggleBtn.onclick = () => {
                toggleBadge();
            };
        }
    }

    // Always ensure product + price sections exist (handles late-loading content & SPA)
    if (!document.getElementById('product-analysis-section')) {
        analyzeProduct(b);
    }
    if (!document.getElementById('price-conv-section')) {
        convertPrice(b);
    }
    if (!document.getElementById('daudas-recharge-btns')) {
        injectRechargeButtons(b);
    }
    if (!document.getElementById('cssbuy-main-btn')) {
        injectCSSBuyButton(b);
    }
};

// --- 6. MÓDULO CSSBUY ---
const handleCSSBuy = () => {
    if (!window.location.href.includes('cssbuy.com')) return;
    const urlParams = new URLSearchParams(window.location.search);
    const itemID = urlParams.get('item-xianyu') || window.location.href.match(/item-xianyu-(\d+)/)?.[1];

    if (!itemID || document.getElementById('cssbuy-daudas-panel')) return;

    const b = document.createElement('div');
    b.id = 'cssbuy-daudas-panel';
    Object.assign(b.style, {
        position: 'fixed', top: '20px', left: '20px', zIndex: '2147483647',
        color: 'white', padding: '18px 20px', borderRadius: '16px',
        backgroundColor: '#2d1b2d',
        boxShadow: '0 6px 24px rgba(114,49,114,0.6)',
        fontFamily: 'Segoe UI, sans-serif', width: '320px',
        border: '1px solid rgba(114,49,114,0.5)', transition: '0.3s'
    });

    b.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
            <div id="cssbuy-toggle-btn" style="display:flex;align-items:center;cursor:pointer;">
                <img src="${FOTO_GRUPO_LOCAL}" style="width:40px;height:40px;border-radius:10px;object-fit:cover;border:1px solid rgba(255,255,255,0.15);">
                <div class="slet-title-text" style="font-weight:bold;font-size:17px;color:#fff;line-height:1.1;margin-left:12px;">Daudas Xianyu</div>
            </div>
            <div class="slet-content" style="display:flex;gap:6px;align-items:center;">
                <div id="cssbuy-btn-minimize" style="cursor:pointer;padding:6px;opacity:0.6;font-weight:bold;color:#fff;font-size:18px;line-height:0.5;">—</div>
            </div>
        </div>

        <div class="slet-content">
            <a href="https://www.goofish.com/item?id=${itemID}" target="_blank" rel="noopener noreferrer"
               style="display:block;width:100%;box-sizing:border-box;text-align:center;
                      background:#ffda00;color:#000;font-weight:900;font-size:16px;
                      padding:14px 0;border-radius:10px;text-decoration:none;
                      letter-spacing:1px;box-shadow:0 3px 10px rgba(255,218,0,0.4);transition:0.2s;"
               onmouseover="this.style.background='#ffe84d';this.style.transform='scale(1.02)'"
               onmouseout="this.style.background='#ffda00';this.style.transform='scale(1)'">
                <img src="${FOTO_GOOFISH_LOCAL}" style="width:20px;height:20px;margin-right:8px;border-radius:4px;object-fit:cover;vertical-align:middle;">
                VER NA XIANYU
            </a>
        </div>
    `;

    document.body.appendChild(b);

    // Recargas (big=true = botões maiores, exclusivo CSSBuy)
    injectRechargeButtons(b, true);

    // Cotação
    (() => {
        if (document.getElementById('price-conv-section')) return;

        if (rateMode === 'auto' && lastAutoRate > 0) taxaYuanReal = lastAutoRate;

        // ── SELETORES DO CSSBUY — .price.flex contém "CNY ￥XXXX.XX" ──
        const getCssBuyPriceEl = () =>
            document.querySelector('.price.flex') ||
            document.querySelector('[class*="price"][class*="flex"]') ||
            document.querySelector('.item-price') ||
            document.querySelector('.buynow-price') ||
            document.querySelector('[class*="item-price"]') ||
            document.querySelector('[class*="buynow"]') ||
            document.querySelector('[id*="price"]') ||
            null;

        // Relê o preço ao vivo — remove "CNY", "￥", "¥", vírgulas
        const getRawYuan = () => {
            const el = getCssBuyPriceEl();
            if (!el) return null;
            return el.innerText.replace(/CNY/gi, '').replace(/[¥￥,]/g, '').trim();
        };

        const rawText = getRawYuan();

        let displayReal = '—';
        const yuan0 = parseYuanValue(rawText || '');
        if (yuan0 !== null && taxaYuanReal > 0) {
            displayReal = (yuan0 / taxaYuanReal).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        }

        const priceDiv = document.createElement('div');
        priceDiv.id = 'price-conv-section';
        priceDiv.className = 'slet-content';
        priceDiv.innerHTML = `
            <hr style="border:0;border-top:1px solid rgba(255,255,255,0.18);margin:12px 0;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
                <span style="font-size:14px;font-weight:900;color:#5efb6e;">💱 Valor em R$</span>
                <input type="number" id="taxa-manual" step="0.01" min="0.01" value="${taxaYuanReal}"
                    style="width:50px;background:rgba(114,49,114,0.4);border:1px solid rgba(255,255,255,0.2);
                           color:#fff;font-size:12px;border-radius:4px;text-align:center;padding:2px;">
            </div>
            <div style="display:flex;gap:6px;align-items:center;margin:6px 0 10px;">
                <select id="taxa-mode" style="flex:1;background:rgba(114,49,114,0.4);border:1px solid rgba(255,255,255,0.2);
                    color:#fff;font-size:12px;border-radius:4px;padding:4px 6px;">
                    <option value="manual" ${rateMode === 'manual' ? 'selected' : ''}>Manual</option>
                    <option value="auto"   ${rateMode === 'auto'   ? 'selected' : ''}>Automática (API)</option>
                </select>
                <button id="taxa-refresh" style="background:rgba(255,255,255,0.15);border:1px solid rgba(255,255,255,0.25);
                    color:#fff;font-size:12px;border-radius:4px;padding:4px 10px;cursor:pointer;font-weight:600;">Atualizar</button>
            </div>
            <div style="font-size:11px;color:#bbb;margin-bottom:8px;">
                Fonte: ${rateMode === 'auto' ? `AwesomeAPI · ${formatRateUpdateLabel()}` : 'Manual'}
            </div>
            <div id="cssbuy-price-display" style="font-size:32px;font-weight:900;color:#fff;letter-spacing:-1px;">
                ${displayReal}
            </div>
            <div style="margin-top:14px;padding-top:10px;border-top:1px solid rgba(114,49,114,0.4);
                font-size:9px;opacity:0.55;text-align:center;line-height:1.4;color:#eee;">
                Análise técnica apenas. Não é recomendação de compra.<br>
                <b>Daudas Helper</b> 2026 · Fork do original por <b>Slet</b><br>
                Licença <a href="https://creativecommons.org/licenses/by-nc-sa/4.0/" target="_blank" style="color:#c084fc;">CC BY-NC-SA 4.0</a>
            </div>
        `;
        b.appendChild(priceDiv);

        const taxaManualInput = document.getElementById('taxa-manual');
        const taxaModeSelect  = document.getElementById('taxa-mode');
        const taxaRefreshBtn  = document.getElementById('taxa-refresh');
        const priceDisplay    = document.getElementById('cssbuy-price-display');

        const refreshDisplay = () => {
            const liveRaw = getRawYuan();
            const yuan = parseYuanValue(liveRaw || '0');
            const real = (yuan && taxaYuanReal > 0)
                ? (yuan / taxaYuanReal).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
                : '—';
            priceDisplay.textContent = real;
        };

        taxaManualInput.disabled         = (rateMode === 'auto');
        taxaRefreshBtn.disabled          = (rateMode !== 'auto');
        taxaRefreshBtn.style.opacity     = rateMode === 'auto' ? '1' : '0.5';
        taxaRefreshBtn.style.cursor      = rateMode === 'auto' ? 'pointer' : 'not-allowed';

        taxaManualInput.addEventListener('change', (e) => {
            const next = toNumberOrDefault(e.target.value, DEFAULT_RATE);
            taxaYuanReal = next > 0 ? next : DEFAULT_RATE;
            writeStorage(RATE_STORAGE_KEY, String(taxaYuanReal));
            refreshDisplay();
        });
        taxaModeSelect.addEventListener('change', async (e) => {
            rateMode = e.target.value === 'auto' ? 'auto' : 'manual';
            writeStorage(RATE_MODE_STORAGE_KEY, rateMode);
            if (rateMode === 'auto') await fetchAutoRate(true);
            else taxaYuanReal = toNumberOrDefault(readStorage(RATE_STORAGE_KEY), DEFAULT_RATE);
            refreshDisplay();
        });
        taxaRefreshBtn.addEventListener('click', async () => {
            if (rateMode !== 'auto') return;
            await fetchAutoRate(true);
            refreshDisplay();
        });

        if (rateMode === 'auto') fetchAutoRate(false).then(() => refreshDisplay());

        // Retry do VALOR: tenta até 5x a cada 3s se ainda mostrar "—" (página carregando)
        let _priceRetry = 0;
        const _priceRetryInterval = setInterval(() => {
            _priceRetry++;
            const display = document.getElementById('cssbuy-price-display');
            if (!display || _priceRetry > 5) { clearInterval(_priceRetryInterval); return; }
            const liveRaw = getRawYuan();
            const yuan = parseYuanValue(liveRaw || '');
            if (yuan !== null && taxaYuanReal > 0) {
                display.textContent = (yuan / taxaYuanReal).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
                clearInterval(_priceRetryInterval);
            }
        }, 3000);
    })();

    const toggleBadge = () => b.classList.toggle('slet-minimized');
    const minBtn    = b.querySelector('#cssbuy-btn-minimize');
    const toggleBtn = b.querySelector('#cssbuy-toggle-btn');
    if (minBtn)    minBtn.onclick    = (e) => { e.stopPropagation(); toggleBadge(); };
    if (toggleBtn) toggleBtn.onclick = toggleBadge;
};


// --- 6b. MÓDULO GOOFISH → CSSBUY (integrado no painel) ---
const CSSBUY_PROMOTION_CODE = '6c5c259d2e0dfee7';
// Botão CSSBuy agora fica dentro do painel principal (btn-cssbuy-inline)
const handleGoofishToCSSBuy = () => {};

// --- 7. EXECUÇÃO ---
const main = () => { 
    injectSilencerStyles(); 
    handleCSSBuy(); 
    handleGoofishToCSSBuy();
    analyzeSeller(); 
};

let mainTimer = null;
let lastUrl = '';
const scheduleMain = () => {
    if (mainTimer) return;
    mainTimer = window.setTimeout(() => {
        mainTimer = null;
        if (window.location.href !== lastUrl) {
            lastUrl = window.location.href;
            main();
            return;
        }
        const b = document.getElementById('seller-status-badge');
        if (b) {
            if (!document.getElementById('product-analysis-section')) analyzeProduct(b);
            if (!document.getElementById('price-conv-section')) convertPrice(b);
            if (!document.getElementById('daudas-recharge-btns')) injectRechargeButtons(b);
            if (!document.getElementById('cssbuy-main-btn')) injectCSSBuyButton(b);
                } else {
            main();
        }
    }, 1000);
};

// Retry convertPrice Xianyu: 5x a cada 3s para páginas com carregamento lento
let _convertRetry = 0;
const _convertRetryInterval = setInterval(() => {
    _convertRetry++;
    if (_convertRetry > 5) { clearInterval(_convertRetryInterval); return; }
    const badge = document.getElementById('seller-status-badge');
    if (!badge) return;
    const sec = document.getElementById('price-conv-section');
    if (sec) {
        // Verifica se o preço ainda está em "—" e tenta atualizar
        const priceDiv = sec.querySelector('[style*="font-size"]');
        if (priceDiv && priceDiv.textContent.trim() === '—') convertPrice(badge);
        else clearInterval(_convertRetryInterval);
    } else {
        convertPrice(badge);
    }
}, 3000);

// Retry analyzeProduct Xianyu: aguarda até 8x para seção existir e não ser genérico
let _analyzeRetry = 0;
const _analyzeRetryInterval = setInterval(() => {
    _analyzeRetry++;
    if (_analyzeRetry > 8) { clearInterval(_analyzeRetryInterval); return; }
    const badge = document.getElementById('seller-status-badge');
    if (!badge) return;
    const sec = document.getElementById('product-analysis-section');
    if (sec) {
        const modeSelect = document.getElementById('analysis-mode');
        if (modeSelect) {
            const currentLabel = modeSelect.options[modeSelect.selectedIndex]?.text || '';
            const isGeneric = currentLabel.toLowerCase().includes('genérico') || currentLabel.toLowerCase().includes('generico');
            if (!isGeneric) { clearInterval(_analyzeRetryInterval); return; }
        } else {
            clearInterval(_analyzeRetryInterval); return;
        }
    }
    if (!sec || (badge._detectRetryCount !== undefined && badge._detectRetryCount > 0)) {
        if (sec) sec.remove();
        analyzeProduct(badge);
    }
}, 3500);
const observer = new MutationObserver(scheduleMain);
observer.observe(document.documentElement, { childList: true, subtree: true });
setTimeout(main, 800);